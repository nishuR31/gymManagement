import { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ImageBackground, ScrollView, useWindowDimensions, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { ArrowLeft, ArrowRight, Fingerprint, Dumbbell, UserRound, KeyRound, BadgeCheck } from 'lucide-react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';

import { useAppDispatch } from '../store/hooks';
import { memberLoginThunk } from '../features/auth/authSlice';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Footer } from '../components/layout/Footer';
import { APP_NAME } from '../utils/env';
import { themeColors } from '../constants/colors';
import { useAppSelector } from '../store/hooks';

const emailSchema = z.object({ email: z.string().email("Enter a valid email address") });
const passwordSchema = z.object({ password: z.string().min(8, "Password must be at least 8 characters").regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/, "Password must be strong") });
const codeSchema = z.object({ code: z.string().min(4, "Enter a valid verification code") });

type EmailFormValues = z.infer<typeof emailSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;
type CodeFormValues = z.infer<typeof codeSchema>;
type AuthStep = "login" | "2fa" | "otp";

export function MemberLoginScreen() {
  const dispatch = useAppDispatch();

  const navigation = useNavigation<any>();
  const theme = useAppSelector((state) => state.theme.theme);
  const activeColors = themeColors[theme === 'amoled' ? 'amoled' : theme === 'dark' ? 'dark' : 'light'];

  const [step, setStep] = useState<AuthStep>("login");
  const [email, setEmail] = useState("");
  const [passwordCache, setPasswordCache] = useState("");
  const [isSimulating, setIsSimulating] = useState(false);

  const { control: controlLogin, handleSubmit: subLogin, formState: { errors: errLogin } } = useForm<EmailFormValues & PasswordFormValues>({ resolver: zodResolver(emailSchema.merge(passwordSchema)) });
  const { control: controlCode, handleSubmit: subCode, formState: { errors: errCode } } = useForm<CodeFormValues>({ resolver: zodResolver(codeSchema) });

  const accessToken = useAppSelector((state) => state.auth.accessToken);

  useEffect(() => {
    if (accessToken) {
      navigation.replace("Dashboard");
    }
  }, [accessToken, navigation]);

  const onFinalLogin = async (pass?: string, currentEmail?: string) => {
    setIsSimulating(true);
    const result = await dispatch(memberLoginThunk({ email: currentEmail || email, password: pass || "" }));
    setIsSimulating(false);

    if (memberLoginThunk.fulfilled.match(result)) {
      if (result.payload.user.mustChangePassword) {
        Toast.show({ type: 'info', text1: 'Password change required', text2: 'Please update your password to continue.' });
        return;
      }
      Toast.show({ type: 'success', text1: 'Welcome back!' });
      navigation.replace("Dashboard");
      return;
    }

    if (memberLoginThunk.rejected.match(result) && result.payload === "2FA_REQUIRED") {
      setPasswordCache(pass || "");
      setStep("2fa");
      Toast.show({ type: 'info', text1: 'Two-factor authentication required', text2: 'Enter the code from your authenticator app.' });
      return;
    }

    if (result.payload === "NOT_A_MEMBER") {
      Toast.show({ type: 'error', text1: 'Access denied', text2: `You are not registered as a member of ${APP_NAME}.` });
      return;
    }

    if (result.payload === "INVALID_CREDENTIALS") {
      Toast.show({ type: 'error', text1: 'Incorrect email or password', text2: 'Please check your credentials and try again.' });
      return;
    }

    Toast.show({
      type: 'error',
      text1: 'Login failed',
      text2: typeof result.payload === 'string' ? result.payload : 'Network or server error. Please try again.',
      visibilityTime: 5000,
    });
  };

  const handleLoginNext = (v: EmailFormValues & PasswordFormValues) => {
    setEmail(v.email);
    onFinalLogin(v.password, v.email);
  };
  const handleCodeSubmit = () => { onFinalLogin(passwordCache, email); };

  const handlePasskey = () => {
    Toast.show({ type: 'info', text1: "Prompting for Passkey…", text2: "Use your biometric or device PIN" });
    onFinalLogin();
  };

  const renderStep = () => {
    if (step === "login") {
      return (
        <View className="space-y-6 mt-4">
          <Controller control={controlLogin} name="email" render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label="Member Email"
              onBlur={onBlur}
              onChangeText={onChange}
              value={value}
              error={errLogin.email?.message}
              autoCapitalize="none"
              keyboardType="email-address"
              placeholder="you@example.com"
            />
          )} />
          <View className="mt-4">
            <Controller control={controlLogin} name="password" render={({ field: { onChange, onBlur, value } }) => (
              <Input
                label="Password"
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                error={errLogin.password?.message}
                secureTextEntry
                placeholder="Enter your password"
              />
            )} />
          </View>
          <Button onPress={subLogin(handleLoginNext)} className="mt-4" isLoading={isSimulating} disabled={isSimulating}>
            <View className="flex-row items-center justify-center">
              <Text style={{ color: activeColors.primaryForeground }} className="font-bold mr-2">Sign In</Text>
              <ArrowRight size={16} color={activeColors.primaryForeground} />
            </View>
          </Button>

          <View className="flex-row items-center my-6">
            <View className="flex-1 h-px" style={{ backgroundColor: activeColors.border }} />
            <Text className="mx-4 text-xs uppercase" style={{ color: activeColors.mutedForeground }}>Or continue with</Text>
            <View className="flex-1 h-px" style={{ backgroundColor: activeColors.border }} />
          </View>

          <View className="gap-3">
            <Button variant="outline" onPress={handlePasskey} isLoading={isSimulating} disabled={isSimulating}>
              <View className="flex-row items-center justify-center">
                <Fingerprint size={20} color={activeColors.foreground} style={{ marginRight: 8 }} />
                <Text style={{ color: activeColors.foreground }} className="font-bold">Continue with Passkey</Text>
              </View>
            </Button>
          </View>
        </View>
      );
    }

    if (step === "2fa" || step === "otp") {
      return (
        <View className="space-y-6 mt-4">
          <View className="flex-row items-center gap-2 mb-4">
            <TouchableOpacity onPress={() => setStep("login")} style={{ backgroundColor: activeColors.secondary }} className="p-2 rounded-full">
              <ArrowLeft size={16} color={activeColors.foreground} />
            </TouchableOpacity>
            <Text style={{ color: activeColors.foreground }} className="text-sm font-medium">
              {step === "2fa" ? "Two-Factor Authentication" : "One-Time Password"}
            </Text>
          </View>
          <Text style={{ color: activeColors.mutedForeground }} className="text-sm mb-4">
            {step === "2fa" ? "Enter the 6-digit code from your authenticator app." : `We sent a code to ${email}.`}
          </Text>
          <Controller control={controlCode} name="code" render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label="Verification Code"
              onBlur={onBlur}
              onChangeText={onChange}
              value={value}
              error={errCode.code?.message}
              placeholder="000000"
              keyboardType="number-pad"
            />
          )} />
          <Button onPress={subCode(handleCodeSubmit)} disabled={isSimulating} className="mt-4">
            {isSimulating
              ? <ActivityIndicator color={activeColors.primaryForeground} />
              : <Text style={{ color: activeColors.primaryForeground }} className="font-bold">Verify & Sign In</Text>}
          </Button>
        </View>
      );
    }

    return null;
  };

  const { width } = useWindowDimensions();
  const isWide = width > 768;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: activeColors.background }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: isWide ? 120 : 80 }}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets={true}
      >
        <View className={`flex-1 ${isWide ? 'flex-row' : 'flex-col'}`}>

          {/* Left Hero Section — always dark (imagery) */}
          <View className={`${isWide ? 'w-1/2' : 'w-full h-56'} bg-zinc-950 relative overflow-hidden`}>
            <ImageBackground
              source={{ uri: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=1169&auto=format&fit=crop" }}
              className="absolute inset-0 w-full h-full opacity-50"
              resizeMode="cover"
            />
            <View className="absolute inset-0 bg-black/40" />

            <SafeAreaView className="flex-1 p-8 lg:p-20 z-10">
              <TouchableOpacity onPress={() => navigation.navigate("Home")} className="flex-row items-center gap-3 absolute top-12 left-8 lg:top-20 lg:left-20 z-20">
                <View className="w-9 h-9 bg-primary items-center justify-center rounded-lg shadow-lg">
                  <Dumbbell size={18} color={activeColors.primaryForeground} />
                </View>
                <Text className="text-lg font-black text-white">{APP_NAME}</Text>
              </TouchableOpacity>

              <View className="flex-1 justify-center items-center w-full">
                {!isWide && (
                  <View className="mt-12 items-center w-full px-4">
                    <Text className="text-3xl font-black text-white leading-tight text-center">Unlock your true potential.</Text>
                  </View>
                )}

                {isWide && (
                  <View className="items-center w-full max-w-2xl">
                    <View className="self-center flex-row items-center bg-white/20 px-4 py-1.5 rounded-full mb-6 border border-white/30">
                      <UserRound size={14} color="#FFF" />
                      <Text className="text-white font-black text-xs uppercase tracking-widest ml-2">Member Access</Text>
                    </View>
                    <Text className="text-5xl font-black text-white leading-tight mb-8 text-center w-full">Unlock your true potential.</Text>
                    <View className="gap-5 items-center w-full mt-4">
                      <View className="flex-row items-center gap-4 w-full justify-center"><BadgeCheck size={24} color={activeColors.primary} /><Text className="font-semibold text-white text-xl">Track your training progress</Text></View>
                      <View className="flex-row items-center gap-4 w-full justify-center"><KeyRound size={24} color={activeColors.primary} /><Text className="font-semibold text-white text-xl">Manage your memberships</Text></View>
                      <View className="flex-row items-center gap-4 w-full justify-center"><Dumbbell size={24} color={activeColors.primary} /><Text className="font-semibold text-white text-xl">Book classes and sessions</Text></View>
                    </View>
                  </View>
                )}
              </View>
            </SafeAreaView>
          </View>

          {/* Right Form Section — fully theme-aware */}
          <View
            className={`${isWide ? 'w-1/2' : 'flex-1'} justify-center p-6`}
            style={{ backgroundColor: activeColors.background, borderLeftColor: activeColors.border, borderLeftWidth: isWide ? 1 : 0 }}
          >
            <View className="w-full max-w-md self-center">

              <View className="flex-row items-center justify-between mb-6">
                <TouchableOpacity onPress={() => navigation.navigate("Home")} className="flex-row items-center gap-2">
                  <ArrowLeft size={16} color={activeColors.mutedForeground} />
                  <Text style={{ color: activeColors.mutedForeground }} className="text-sm font-medium">Back to website</Text>
                </TouchableOpacity>
                {!isWide && (
                  <View className="flex-row items-center gap-2">
                    <Dumbbell size={18} color={activeColors.primary} />
                    <Text style={{ color: activeColors.foreground }} className="font-black">{APP_NAME}</Text>
                  </View>
                )}
              </View>

              <Text style={{ color: activeColors.foreground }} className="text-3xl font-black mb-2">Member Login</Text>
              <Text style={{ color: activeColors.mutedForeground }} className="text-sm mb-6">Access your personal gym portal securely.</Text>

              <View className="min-h-[280px]">
                {renderStep()}
              </View>

              <View className="mt-8 pt-6" style={{ borderTopWidth: 1, borderTopColor: activeColors.border }}>
                <Text style={{ color: activeColors.foreground }} className="text-sm font-medium">Staff or Administrator?</Text>
                <TouchableOpacity onPress={() => navigation.navigate("Login")} className="flex-row items-center mt-2">
                  <Text style={{ color: activeColors.primary }} className="text-sm font-bold mr-2">Use staff portal</Text>
                  <ArrowRight size={14} color={activeColors.primary} />
                </TouchableOpacity>
              </View>

            </View>
          </View>

        </View>
        <Footer />
      </ScrollView>
      <Toast />
    </KeyboardAvoidingView>
  );
}
